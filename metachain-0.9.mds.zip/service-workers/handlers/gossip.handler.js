/**
 * MetaChain Service Worker - Gossip Handler
 * Handles peer exchange (gossip) protocol
 */

function loadListingsMap(callback) {
  MDS.sql(
    "SELECT owner_publickey, listings, timestamp FROM DISCOVERED_LISTINGS",
    function (res) {
      var map = {};
      if (res.status && res.rows) {
        for (var i = 0; i < res.rows.length; i++) {
          var row = res.rows[i];
          var pk = row.OWNER_PUBLICKEY || row.owner_publickey;
          if (!pk) continue;
          var listJson = row.LISTINGS || row.listings || "[]";
          var parsed = [];
          try {
            parsed = JSON.parse(
              typeof listJson === "string"
                ? listJson
                : JSON.stringify(listJson),
            );
          } catch (e) {
            parsed = [];
          }
          map[pk] = {
            listings: parsed,
            timestamp: row.TIMESTAMP || row.timestamp || 0,
          };
        }
      }
      callback(map);
    },
  );
}

function handleGetPeers(pubkey, maxjson) {

  loadListingsMap(function (listingsMap) {
    // Fetch known peers
    var peerSql =
      "SELECT * FROM DISCOVERED_PEERS ORDER BY last_seen DESC LIMIT 50";
    MDS.sql(peerSql, function (res) {
      if (res.status && res.rows && res.rows.length > 0) {
        var peers = [];
        for (var i = 0; i < res.rows.length; i++) {
          var row = res.rows[i];
          var publickey = row.PUBLICKEY || row.publickey;

          // Parse extra_data
          var avatar = "";
          var country = "";
          var languages = [];
          var bio = row.BIO || "";
          var timestamp = 0;

          var minimaaddress = row.MINIMAADDRESS || "";
          if (row.EXTRA_DATA) {
            try {
              var extraObj = JSON.parse(row.EXTRA_DATA);
              avatar = extraObj.avatar || "";
              country = extraObj.country || "";
              languages = extraObj.languages || [];
              if (!bio && extraObj.bio) bio = extraObj.bio;
              timestamp = extraObj.timestamp || 0;
              if (!minimaaddress && extraObj.minimaaddress) minimaaddress = extraObj.minimaaddress;
            } catch (e) {}
          }

          var listingEntry = listingsMap[publickey];

          var ancc = row.ALLOW_NON_CONTACT_CHATS;
          peers.push({
            pubkey: publickey,
            alias: row.ALIAS,
            bio: bio,
            address: row.ADDRESS,
            allowNonContactChats:
              ancc === 1 || ancc === true || ancc === "1" || ancc === "true" || ancc === "TRUE",
            avatar: avatar,
            country: country,
            languages: languages,
            minimaaddress: minimaaddress,
            listings: listingEntry ? listingEntry.listings : undefined,
            timestamp: timestamp || (listingEntry ? listingEntry.timestamp : 0),
          });
        }

        // Send response (prefer address when provided to avoid contact requirement)
        var replyPayload = {
          app: "metachain",
          type: "peers_response",
          peers: peers,
        };
        var replyHex = "0x" + utf8ToHex(JSON.stringify(replyPayload)).toUpperCase();
        var targetAddress = maxjson && maxjson.address ? maxjson.address : "";

        if (targetAddress) {
            var sendCmd = "maxima action:send to:" + targetAddress + " application:metachain data:" + replyHex + " poll:false";
            MDS.cmd(sendCmd, function (sendRes) {
                if (sendRes && sendRes.status === false) {
                    if (SW_DEBUG) MDS.log("⚠️ [GOSSIP] Failed to send peers to address: " + sendRes.error);
                } else {
                    if (SW_DEBUG) MDS.log("✅ [GOSSIP] Sent " + peers.length + " peers to " + targetAddress);
                }
                // Always also send via smartSend (publickey fallback with resolution)
                smartSend(pubkey, "metachain", replyHex, "GOSSIP-REPLY", false);
            });
        } else {
            smartSend(pubkey, "metachain", replyHex, "GOSSIP-REPLY", false);
        }
      }
    });
  });
}

function handlePeersResponse(pubkey, maxjson) {
  var peerCount = maxjson.peers ? maxjson.peers.length : 0;
  var senderAlias = pubkey ? pubkey.substring(0, 10) : "P2P-broadcast";

  if (peerCount === 0) return;

  if (maxjson.peers && Array.isArray(maxjson.peers)) {
    var processedCount = 0;
    var skippedCount = 0;

    for (var i = 0; i < maxjson.peers.length; i++) {
      var peer = maxjson.peers[i];

      if (peer.pubkey && peer.address && peer.alias) {
        handleBeacon(peer, "GOSSIP");
        processedCount++;
      } else {
        if (SW_DEBUG) {
          MDS.log(
            "⚠️ [GOSSIP-PEER] Skipping incomplete peer - pubkey:" +
              !!peer.pubkey +
              " address:" +
              !!peer.address +
              " alias:" +
              !!peer.alias,
          );
        }
        skippedCount++;
      }
    }

    if (skippedCount > 0 && SW_DEBUG) MDS.log("⚠️ [GOSSIP] Skipped " + skippedCount + " incomplete peers");
  } else {
    if (SW_DEBUG) MDS.log("⚠️ [GOSSIP] No valid peers array in response");
  }
}

function startGossip() {

  // Try discovered peers first
  MDS.sql(
    "SELECT * FROM DISCOVERED_PEERS ORDER BY last_seen DESC LIMIT " + (typeof DISCOVERY_LIMIT !== "undefined" ? DISCOVERY_LIMIT : 5),
    function (res) {
      if (res.status && res.rows && res.rows.length > 0) {
        var pubkeys = [];
        for (var i = 0; i < res.rows.length; i++) {
          pubkeys.push(res.rows[i].PUBLICKEY);
        }
        var validPubkeys = pubkeys.filter(function (pk) {
          return pk !== MY_MAXIMA_PK;
        });

        if (validPubkeys.length > 0) {
          askPeers(validPubkeys);
        } else {
          if (SW_DEBUG) {
            MDS.log(
              "⚠️ [GOSSIP] Only self found in discovery — triggering MLS bootstrap fallback.",
            );
          }
          if (typeof bootstrapFromMLS === "function") {
            bootstrapFromMLS();
          }
        }
      } else {
        // Fallback to contacts
        MDS.cmd("maxcontacts", function (contactRes) {
          if (
            contactRes.status &&
            contactRes.response.contacts &&
            contactRes.response.contacts.length > 0
          ) {
            var targets = [];
            for (
              var i = 0;
              i < Math.min(5, contactRes.response.contacts.length);
              i++
            ) {
              targets.push(contactRes.response.contacts[i].publickey);
            }
            askPeers(targets);
          } else {
            if (SW_DEBUG) {
              MDS.log(
                "⚠️ [GOSSIP] No peers or contacts — triggering MLS bootstrap fallback.",
              );
            }
            if (typeof bootstrapFromMLS === "function") {
              bootstrapFromMLS();
            }
          }
        });
      }
    },
  );
}

function askPeers(pubkeys) {
  MDS.cmd("maxima action:info", function (maxInfo) {
    var myAlias = maxInfo.status ? maxInfo.response.name : "Anonymous";
    var myAddress = maxInfo.status
      ? maxInfo.response.mls || maxInfo.response.contact || ""
      : "";

    var requestPayload = {
      app: "metachain",
      type: "get_peers",
      alias: myAlias,
      address: myAddress,
    };

    var hexData =
      "0x" + utf8ToHex(JSON.stringify(requestPayload)).toUpperCase();

    for (var i = 0; i < pubkeys.length; i++) {
      var pk = pubkeys[i];
      if (MY_MAXIMA_PK && pk === MY_MAXIMA_PK) continue;

      smartSend(pk, "metachain", hexData, "GOSSIP-ASK", false);
    }
  });
}

function sendWelcomePackage(targetPubkey, targetAlias, targetAddress) {
  if (MY_MAXIMA_PK && targetPubkey === MY_MAXIMA_PK) return;

  if (SW_DEBUG) MDS.log("🎁 [GOSSIP] Sending Welcome Package to " + targetAlias);

  loadListingsMap(function (listingsMap) {
    var peerSql =
      "SELECT * FROM DISCOVERED_PEERS ORDER BY last_seen DESC LIMIT 50";
    MDS.sql(peerSql, function (res) {
      if (res.status && res.rows && res.rows.length > 0) {
        var peers = [];
        for (var i = 0; i < res.rows.length; i++) {
          var row = res.rows[i];
          var publickey = row.PUBLICKEY || row.publickey;

          var avatar = "";
          var country = "";
          var languages = [];
          var bio = row.BIO || "";
          var timestamp = 0;
          var minimaaddress2 = row.MINIMAADDRESS || "";

          if (row.EXTRA_DATA) {
            try {
              var extraObj = JSON.parse(row.EXTRA_DATA);
              avatar = extraObj.avatar || "";
              country = extraObj.country || "";
              languages = extraObj.languages || [];
              if (!bio && extraObj.bio) bio = extraObj.bio;
              timestamp = extraObj.timestamp || 0;
              if (!minimaaddress2 && extraObj.minimaaddress) minimaaddress2 = extraObj.minimaaddress;
            } catch (e) {}
          }

          var listingEntry = listingsMap[publickey];

          var ancc2 = row.ALLOW_NON_CONTACT_CHATS;
          peers.push({
            pubkey: publickey,
            alias: row.ALIAS,
            bio: bio,
            address: row.ADDRESS,
            allowNonContactChats:
              ancc2 === 1 || ancc2 === true || ancc2 === "1" || ancc2 === "true" || ancc2 === "TRUE",
            avatar: avatar,
            country: country,
            languages: languages,
            minimaaddress: minimaaddress2,
            listings: listingEntry ? listingEntry.listings : undefined,
            timestamp: timestamp || (listingEntry ? listingEntry.timestamp : 0),
          });
        }

        var responsePayload = {
          app: "metachain",
          type: "peers_response",
          peers: peers,
        };

        var hexData =
          "0x" + utf8ToHex(JSON.stringify(responsePayload)).toUpperCase();

        // Send via Maxima unicast directly to the target
        // Prioritize to:address (no contact required), fallback to publickey
        if (targetAddress) {
            var sendCmd = "maxima action:send to:" + targetAddress + " application:metachain data:" + hexData + " poll:false";
            MDS.cmd(sendCmd, function (sendRes) {
                if (sendRes && sendRes.status === false) {
                    if (SW_DEBUG) MDS.log("⚠️ [GOSSIP] Failed to send Welcome Package to " + targetAddress + ": " + sendRes.error);
                } else {
                    if (SW_DEBUG) MDS.log("✅ [GOSSIP] Welcome Package sent to " + targetAddress);
                }
                // Always also send via smartSend (publickey fallback with resolution)
                smartSend(targetPubkey, "metachain", hexData, "GOSSIP-WELCOME", false);
            });
        } else {
            smartSend(targetPubkey, "metachain", hexData, "GOSSIP-WELCOME", false);
        }
      }
    });
  });
}
