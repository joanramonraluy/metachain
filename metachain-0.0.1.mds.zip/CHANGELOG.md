# Changelog

##### [0.0.1] - 10 December 2025

- Initial version
